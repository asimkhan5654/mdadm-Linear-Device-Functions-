# SU24-lab2
Checkout Readme_LAB2.pdf
