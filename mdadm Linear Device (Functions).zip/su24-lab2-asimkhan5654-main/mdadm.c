// Asim Khan
//CMPSC 311 SU24
//LAB 2

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "mdadm.h"
#include "jbod.h"

// Static variable for tracking mounting state
static int mounted = 0;

// Function for getting  mounted state
// Return current mounted state  (1 after mounted, 0 otherwise).
int isMounted(void) 
{
  return mounted;
}

// Function for setting up mounted state
// Parameters:- state: The updated state to be set (1 being mounted and 0 being unmounted).
void set_mounted(int state) 
{
  mounted = state;
}

// JBOD mounting function 
// 1 gets returned If the mount op was successful ; if not, -1
int mdadm_mount(void) 
{
  if (!isMounted()) 
  {
    int result = jbod_operation(JBOD_MOUNT, NULL);
    if (result == 0) 
    {
      set_mounted(1);
      return 1;
    }
  }
  return -1;
}

// JBOD mounting function
// 1 gets returned if the unmount op was successful, 1; if not, -1
int mdadm_unmount(void) 
{
  if (isMounted()) // Verify system is mounted
  {
    // Perform unmount op
    int result = jbod_operation(JBOD_UNMOUNT, NULL);
    if (result == 0) 
    {
      // Assign 0 (false) to mounted state.
      set_mounted(0);
      // Success returned
      return 1; 
    }
  }
  // If op failed or the file has already been unmounted, return failure.
  return -1;
}
 
 // Helper function for reading and seeking  op on  JBOD 
// Parameters:- disk_num: The  disk number that is to be seeked,  block_num: The block number that is to be seeked, temp_block: Pointer to buffer containing the read block
// If the operations were successful, returns 0; if not, returns -1.
 int perform_jbod_seek_and_read(uint32_t disk_num, uint32_t block_num, uint8_t *temp_block) 
 {
  // Seek to specified disk
  if (jbod_operation(JBOD_SEEK_TO_DISK | (disk_num << 6), NULL) != 0)
   {
    return -1; // Seek to disk failed
  }

  // // Seek to specified block
  if (jbod_operation(JBOD_SEEK_TO_BLOCK | (block_num << 10), NULL) != 0) 
  {
    return -1; // Seek to block failed
  }

  if (jbod_operation(JBOD_READ_BLOCK, temp_block) != 0) 
  {
    return -1; // Read to block failed
  }

  return 0; // Success return
}


// Function to read data from JBOD
// Parameters:- start_addr: starting address to read from,  read_len: length of data that is to be read, read_buf: Pointer to buffer containing the read data
// If successful, returns total number of bytes read; if not, returns -1.
int mdadm_read(uint32_t start_addr, uint32_t read_len, uint8_t *read_buf) 
{
  // If system is not mounted, ensure reads fail.
  if (!isMounted()) 
  {
    return -1; 
  }
  // Allow readings of 0 length w/ NULL pointer.
  if (read_len == 0 && read_buf == NULL) 
  {
    return 0; 
  }
  // Parameter validation
  if (read_buf == NULL || read_len > 1024 || (start_addr + read_len) > (JBOD_NUM_DISKS * JBOD_DISK_SIZE)) 
  {
    return -1; 
  }
  
  // Variables initialized for tracking length, buffer offset, and current address.
  uint32_t current_addr = start_addr;
  uint32_t buf_offset = 0;
  uint32_t remaining_len = read_len;

  // For loop to read data in blocks
  for (; remaining_len > 0;) 
  {
    // Calculate disk number, block number, and offset within block
    uint32_t disk_num = current_addr / JBOD_DISK_SIZE;
    uint32_t block_num = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
    uint32_t block_offset = current_addr % JBOD_BLOCK_SIZE;
    uint32_t read_size = (block_offset + remaining_len > JBOD_BLOCK_SIZE) ? JBOD_BLOCK_SIZE - block_offset : remaining_len;

    
    uint8_t temp_block[JBOD_BLOCK_SIZE]; // Temp buffer for holding block data
    
    // Seek and read operations execution
    if (perform_jbod_seek_and_read(disk_num, block_num, temp_block) != 0) 
    {
      return -1; // Seek and read operation failed
    }

    // Transfer/copy the block's data to read buffer.
    for (uint32_t i = 0; i < read_size; i++) 
    {
      read_buf[buf_offset + i] = temp_block[block_offset + i];
    }

    // Update current address, buffer offset, & remaining length
    current_addr = current_addr + read_size;
    buf_offset = buf_offset + read_size;
    remaining_len = remaining_len - read_size;
  }

  return read_len; // Return total number of read bytes
}
